///<reference path="../headers/common.d.ts" />

import angular from 'angular';
import _ from 'lodash';

export class DruidConfigCtrl {
  static templateUrl = 'partials/config.html';
  current: any;
}
